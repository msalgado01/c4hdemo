Original project name: BCBSNC_training
Exported on: 10/02/2018 12:46:28
Exported by: ATTUNITY_LOCAL\Manuel.Salgado
