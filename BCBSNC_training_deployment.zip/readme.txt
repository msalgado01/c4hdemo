Original project name: BCBSNC_training
Exported on: 10/02/2018 14:40:09
Exported by: ATTUNITY_LOCAL\Manuel.Salgado
